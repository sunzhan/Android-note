package com.sun.wxtest.beans;

import java.util.ArrayList;

/**
 * Created by Administrator on 2016/7/21.
 */
public class SortBean {
    private String retCode;
    private String msg;
    private ArrayList<SortResultBean> result;

    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public ArrayList<SortResultBean> getResult() {
        return result;
    }

    public void setResult(ArrayList<SortResultBean> result) {
        this.result = result;
    }
}
