package com.sun.wxtest.beans;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2016/7/22.
 */
public class ListBean {
    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public ListResultBean getResult() {
        return result;
    }

    public void setResult(ListResultBean result) {
        this.result = result;
    }

    private String retCode;
    private String msg;
    private ListResultBean result;
}
