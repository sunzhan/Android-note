package com.sun.wxtest.activity;

import android.content.DialogInterface;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.DialogPreference;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.sun.wxtest.R;
import com.sun.wxtest.adapter.MyPagerAdapter;
import com.sun.wxtest.beans.SortBean;
import com.sun.wxtest.beans.SortResultBean;
import com.sun.wxtest.global.GlobalParam;
import com.sun.wxtest.util.ShowToastUtil;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private Handler handler;
    private RecyclerView recyclerView;
//    private PagerSlidingTabStrip tabs;
    private TabLayout tabs;
    private Toolbar toolbar;
    private ViewPager pager;
    private ArrayList<SortResultBean> sortResultBeenList = new ArrayList<>();
    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();

        handler = new Handler() {


            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (msg.what == 0) {
                    Gson gson = new Gson();
                    SortBean sortBean = gson.fromJson(msg.obj.toString(), SortBean.class);
                    String retCode = sortBean.getRetCode();
                    sortResultBeenList = sortBean.getResult();
                    Log.d("MainActivity", "retCode==" + retCode + ", sortResultBeenList==" + sortResultBeenList + ", msg==" + sortBean.getMsg());
                    pager.setAdapter(new MyPagerAdapter(getSupportFragmentManager(), sortResultBeenList));
                    tabs.setupWithViewPager(pager);
                } else {
                    Log.d("MainActivity", "请求失败");
                    Toast.makeText(MainActivity.this, "请求失败", Toast.LENGTH_SHORT).show();
                }
            }
        };

    }

    private void initView() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setTitle("微信精选");
        getSupportActionBar().setHomeButtonEnabled(true); //设置返回键可用
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);
            //创建返回键，并实现打开关/闭监听
            ActionBarDrawerToggle mDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
            mDrawerToggle.syncState();//初始化状态
            drawerLayout.setDrawerListener(mDrawerToggle);
            NavigationView navigationView = (NavigationView) findViewById(R.id.navi_view);
            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(MenuItem item) {
                    switch (item.getItemId()){
                        case R.id.navi_menu_1:
//                        ShowToastUtil.showToast(MainActivity.this, "选中1");
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle("Title")
                                    .setMessage("Message")
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener(){
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            ShowToastUtil.showToast(MainActivity.this, "OK");
                                        }
                                    })
                                    .setNegativeButton("Cancle", new DialogInterface.OnClickListener(){
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            ShowToastUtil.showToast(MainActivity.this, "Cancle");
                                        }
                                    }).show();
                            item.setChecked(true);
                            break;
                        case R.id.navi_menu_2:
                            ShowToastUtil.showToast(MainActivity.this, "选中2");
                            item.setChecked(true);
                            break;
                        case R.id.navi_menu_3:
                            Snackbar.make(toolbar, "Hello", Snackbar.LENGTH_LONG).setAction("NO", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    ShowToastUtil.showToast(MainActivity.this, "NO");
                                }
                            }).show();
                            item.setChecked(true);
                            break;
                        case R.id.sub_1:
                            ShowToastUtil.showToast(MainActivity.this, "sub_1");
                            break;
                        case R.id.sub_2:
                            ShowToastUtil.showToast(MainActivity.this, "sub_2");
                            break;

                    }
                    drawerLayout.closeDrawers();
                    return true;
                }
        });
        tabs = (TabLayout) findViewById(R.id.tabs);
        pager = (ViewPager) findViewById(R.id.pager);
        requsetData();
    }



    private void requsetData() {
        OkHttpClient okHttpClient = new OkHttpClient();
        Request request = new Request.Builder().url(GlobalParam.SORTURL).build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
                Message msg = new Message();
                msg.what = 1;
                handler.sendMessage(msg);
            }

            @Override
            public void onResponse(Response response) throws IOException {
                String str = response.body().string().toString();
//                Log.d("MainActivity", str);
                Message msg = new Message();
                msg.obj = str;
                msg.what = 0;
                handler.sendMessage(msg);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
