package com.sun.wxtest.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.sun.wxtest.R;
import com.sun.wxtest.activity.MainActivity;
import com.sun.wxtest.activity.WebViewActivity;
import com.sun.wxtest.adapter.MyAdapter;
import com.sun.wxtest.beans.ListBean;
import com.sun.wxtest.beans.ListResultBean;
import com.sun.wxtest.beans.NewsListBean;
import com.sun.wxtest.global.GlobalParam;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Administrator on 2016/7/22.
 */
public class ContentFragment extends Fragment {
    private Context context;
    private Handler handler;
    private String title;
    private String cid;
    private ArrayList<NewsListBean> newsList;

    public static Fragment getInstance(Bundle bundle){
        ContentFragment contentFragment = new ContentFragment();
        contentFragment.setArguments(bundle);
        return contentFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_layout, container,false);
    }

    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        title = getArguments().getString("title");
        cid = getArguments().getString("cid");
//        Log.d("ContentFragment", "cid=="+cid);
        handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (msg.what==0){
                    Log.d("ContentFragment", "cid=="+cid+"shoudaole"+msg.obj);
                    initview(view, msg.obj+"");
                }
            }
        };

        initData();

    }

    private void initData() {
        requestData();
    }

    private void requestData() {
        OkHttpClient okHttpClient = new OkHttpClient();
        Request request = new Request.Builder().url(GlobalParam.LISTURL+cid).build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
                Message msg = new Message();
                msg.what = 1;
                handler.sendMessage(msg);
            }

            @Override
            public void onResponse(Response response) throws IOException {
                String str = response.body().string().toString();
                Log.d("ContentFragment", str);
                Message msg = new Message();
                msg.obj = str;
                msg.what = 0;
                handler.sendMessage(msg);
            }
        });
    }

    private void initview(View view, String string) {
        TextView textView = (TextView) view.findViewById(R.id.fragment_text);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.fragment_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        Gson gson = new Gson();
        ListBean listBean = gson.fromJson(string, ListBean.class);
        ListResultBean listResultBean = listBean.getResult();
        newsList = listResultBean.getList();
//        textView.setText(title);
        MyAdapter myAdapter = new MyAdapter(getContext(),newsList);
        myAdapter.setOnItemClickListener(new MyAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Log.d("ContentFragment", "点击" + position);
                Intent intent = new Intent(getContext(), WebViewActivity.class);
                intent.putExtra("url", newsList.get(position).getSourceUrl());
                startActivity(intent);
            }

            @Override
            public void onLongItemClick(View view, int position) {
                Log.d("ContentFragment", "长按" + position);
            }
        });
                recyclerView.setAdapter(myAdapter);
//        textView.setText(getArguments().getString("title"));
    }
}
