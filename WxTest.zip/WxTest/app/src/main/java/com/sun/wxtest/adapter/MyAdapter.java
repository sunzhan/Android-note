package com.sun.wxtest.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.sun.wxtest.R;
import com.sun.wxtest.beans.NewsListBean;

import java.util.ArrayList;

/**
 * Created by Administrator on 2016/7/22.
 */
public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    Context context;
    ArrayList<NewsListBean> newsListBeenList;
    DisplayImageOptions options;

    public MyAdapter(Context context, ArrayList<NewsListBean> newsListBeenList) {
        this.context = context;
        this.newsListBeenList = newsListBeenList;

        options = new DisplayImageOptions.Builder()
                .showImageOnLoading(R.mipmap.ic_stub) // 设置图片下载期间显示的图片
                .showImageForEmptyUri(R.mipmap.ic_empty) // 设置图片Uri为空或是错误的时候显示的图片
                .showImageOnFail(R.mipmap.ic_error) // 设置图片加载或解码过程中发生错误显示的图片
                .cacheInMemory(true) // 设置下载的图片是否缓存在内存中
                .cacheOnDisk(true) // 设置下载的图片是否缓存在SD卡中
                .displayer(new RoundedBitmapDisplayer(20)) // 设置成圆角图片
                .build(); // 构建完成
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        MyViewHolder myViewHolder = new MyViewHolder(LayoutInflater.from(context)
                .inflate(R.layout.card_view, parent, false));
        return myViewHolder;
    }
    public interface OnItemClickListener{
        void onItemClick(View view, int position);
        void onLongItemClick(View view, int position);
    }
    private OnItemClickListener onItemClickListener;
    public void setOnItemClickListener(OnItemClickListener onItemClickListener){
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        holder.titleText.setText(newsListBeenList.get(position).getTitle());
        holder.timeText.setText(newsListBeenList.get(position).getPubTime());
        Log.d("MyAdapter", "网页链接："+newsListBeenList.get(position).getSourceUrl());
        Log.d("MyAdapter", "图片链接："+newsListBeenList.get(position).getThumbnails());
        String imgUrl = newsListBeenList.get(position).getThumbnails();
        String[] imgArray = null;
        if(imgUrl!=null) {
            imgArray = imgUrl.split("\\$");
            Log.d("MyAdapter", "图片数组长度：" + imgArray.length);
            holder.imageView.setVisibility(View.VISIBLE);
            ImageLoader.getInstance().displayImage(imgArray[0], holder.imageView, options);
        }else{

        }
        if(onItemClickListener!=null){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onItemClickListener.onItemClick(holder.itemView, holder.getLayoutPosition());
                }
            });
            holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    onItemClickListener.onLongItemClick(holder.itemView, holder.getLayoutPosition());
                    return false;
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return newsListBeenList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView titleText;
        ImageView imageView;
        TextView timeText;

        public MyViewHolder(View itemView) {
            super(itemView);
            titleText = (TextView) itemView.findViewById(R.id.title);
            imageView =  (ImageView) itemView.findViewById(R.id.img);
            timeText = (TextView) itemView.findViewById(R.id.time);
        }
    }
}
