package com.sun.wxtest.beans;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2016/7/22.
 */
public class ListResultBean {
    public int getCurPage() {
        return curPage;
    }

    public void setCurPage(int curPage) {
        this.curPage = curPage;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public ArrayList<NewsListBean> getList() {
        return list;
    }

    public void setList(ArrayList<NewsListBean> list) {
        this.list = list;
    }

    private int curPage;
    private int total;
    private ArrayList<NewsListBean> list;
}
