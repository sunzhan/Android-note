package com.sun.wxtest.beans;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2016/7/21.
 */
public class SortResultBean implements Parcelable{
    private  String cid;

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private  String name;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(cid);
        dest.writeString(name);
    }
    public static final Parcelable.Creator<SortResultBean> CREATOR = new Creator<SortResultBean>(){

        @Override
        public SortResultBean createFromParcel(Parcel source) {
            return new SortResultBean(source);
        }

        @Override
        public SortResultBean[] newArray(int size) {
            return new SortResultBean[size];
        }
    };
    private  SortResultBean(Parcel in){
        cid = in.readString();
        name = in.readString();
    }
}
