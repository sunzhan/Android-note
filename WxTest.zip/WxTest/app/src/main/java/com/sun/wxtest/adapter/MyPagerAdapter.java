package com.sun.wxtest.adapter;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.ViewGroup;

import com.sun.wxtest.beans.SortResultBean;
import com.sun.wxtest.fragment.ContentFragment;

import java.util.ArrayList;

/**
 * Created by Administrator on 2016/7/22.
 */
public class MyPagerAdapter extends FragmentPagerAdapter{
    private ArrayList<SortResultBean> sortResultBeenList;
    public MyPagerAdapter(FragmentManager fm, ArrayList<SortResultBean> sortResultBeenList) {
        super(fm);
        this.sortResultBeenList = sortResultBeenList;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return sortResultBeenList.get(position).getName();
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        return super.instantiateItem(container, position);
    }

    @Override
    public Fragment getItem(int position) {
        Bundle b = new Bundle();
        b.putString("title", sortResultBeenList.get(position).getName());
        b.putString("cid", sortResultBeenList.get(position).getCid());
        System.out.println(sortResultBeenList.get(position).getCid());
//        b.putParcelableArrayList("list", sortResultBeenList);

        return ContentFragment.getInstance(b);
    }

    @Override
    public int getCount() {
        return sortResultBeenList.size();
    }
}
