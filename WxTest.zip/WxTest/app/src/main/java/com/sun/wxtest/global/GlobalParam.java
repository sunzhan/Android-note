package com.sun.wxtest.global;

/**
 * Created by Administrator on 2016/7/22.
 */
public class GlobalParam {
    public static String SORTURL = "http://apicloud.mob.com/wx/article/category/query?key=15375df9cf9c3";
    public static String LISTURL = "http://apicloud.mob.com/wx/article/search?key=15375df9cf9c3&cid=";
}
